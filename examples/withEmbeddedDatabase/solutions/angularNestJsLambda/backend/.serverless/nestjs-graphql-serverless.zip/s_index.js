var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'niknicius',
applicationName: 'angular-nest-js-prisma-dev',
appUid: 'kZhRbR5lSB66lzhFql',
orgUid: 'StjF0x2Dx3TlqC227v',
deploymentUid: 'cbe86b5b-8f8d-411e-8975-d594899bc7d9',
serviceName: 'nestjs-graphql-serverless',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'nestjs-graphql-serverless-dev-index', timeout: 6}
try {
  const userHandler = require('./dist/serverless.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
