var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
orgId: 'niknicius',
applicationName: 'angular-nest-js-prisma-dev',
appUid: 'kZhRbR5lSB66lzhFql',
orgUid: 'StjF0x2Dx3TlqC227v',
deploymentUid: '5c1d31db-b693-41d5-9446-df3070a4314a',
serviceName: 'nestjs-graphql-serverless-postgresql',
stageName: 'dev',
pluginVersion: '3.3.0'})
const handlerWrapperArgs = { functionName: 'nestjs-graphql-serverless-postgresql-dev-index', timeout: 6}
try {
  const userHandler = require('./dist/serverless.js')
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
